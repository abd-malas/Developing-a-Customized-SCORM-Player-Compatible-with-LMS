
/*
  Minimal SCORM 1.2 API wrapper
  - Finds the API adapter in the window hierarchy
  - Provides LMSInitialize, LMSFinish, LMSSetValue, LMSGetValue, LMSCommit, LMSGetLastError, LMSGetErrorString, LMSGetDiagnostic
*/
(function(global){
  var api = null;
  var maxTries = 500;

  function findAPI(win) {
    var tries = 0;
    while (win && !win.API && win.parent && win.parent != win) {
      tries++;
      if (tries > maxTries) return null;
      win = win.parent;
    }
    return win ? win.API : null;
  }

  function getAPI() {
    if (api) return api;
    // Try current window, then opener
    api = findAPI(window) || (window.opener && findAPI(window.opener)) || null;
    return api;
  }

  function isReady() { return !!getAPI(); }

  var initialized = false;
  function LMSInitialize(arg){
    var a = getAPI();
    if(!a) { console.warn("SCORM API not found"); return "false"; }
    if(initialized) return "true";
    var res = a.LMSInitialize(arg || "");
    if(res == "true") initialized = true;
    return res;
  }
  function LMSFinish(arg){
    var a = getAPI();
    if(!a) return "false";
    var res = a.LMSFinish(arg || "");
    initialized = false;
    return res;
  }
  function LMSGetValue(el){
    var a = getAPI();
    if(!a) return "";
    return a.LMSGetValue(el);
  }
  function LMSSetValue(el,val){
    var a = getAPI();
    if(!a) return "false";
    return a.LMSSetValue(el, String(val));
  }
  function LMSCommit(arg){
    var a = getAPI();
    if(!a) return "false";
    return a.LMSCommit(arg || "");
  }
  function LMSGetLastError(){ var a=getAPI(); return a ? a.LMSGetLastError() : "101"; }
  function LMSGetErrorString(c){ var a=getAPI(); return a ? a.LMSGetErrorString(c) : "General Exception"; }
  function LMSGetDiagnostic(c){ var a=getAPI(); return a ? a.LMSGetDiagnostic(c) : "API not found"; }

  // expose
  global.SCORM = {
    isReady:isReady,
    LMSInitialize:LMSInitialize,
    LMSFinish:LMSFinish,
    LMSGetValue:LMSGetValue,
    LMSSetValue:LMSSetValue,
    LMSCommit:LMSCommit,
    LMSGetLastError:LMSGetLastError,
    LMSGetErrorString:LMSGetErrorString,
    LMSGetDiagnostic:LMSGetDiagnostic
  };
})(window);
