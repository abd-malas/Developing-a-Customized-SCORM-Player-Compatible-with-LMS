
/* Simple HTML5 player that tracks:
   - cmi.core.lesson_location
   - cmi.suspend_data (JSON string)
   - cmi.core.lesson_status (not attempted / incomplete / completed / passed / failed)
   - cmi.core.score.raw (0-100)
*/
const slides = [
  { id:"intro", title:"Welcome", type:"content", html:`
      <h2>Welcome to SCORM Player Demo</h2>
      <p>This is a minimal SCO demonstrating resume, progress, and scoring.</p>
      <ul>
        <li>Use the TOC or Next/Prev to navigate.</li>
        <li>Your progress is tracked to the LMS.</li>
      </ul>
  `},
  { id:"topic1", title:"Topic 1 - Basics", type:"content", html:`
      <h2>SCORM Basics</h2>
      <p>SCORM defines how content (SCO) communicates with the LMS.</p>
      <p>We will store <code>lesson_location</code> and <code>suspend_data</code> so you can resume later.</p>
  `},
  { id:"quiz1", title:"Quick Quiz", type:"quiz", question:"SCORM mainly standardizes how _____ and the LMS communicate.",
    choices:["Students","Content","Instructors","Browsers"], correctIndex:1
  },
  { id:"summary", title:"Summary", type:"content", html:`
      <h2>You're done 🎉</h2>
      <p>Your status should be <strong>completed</strong>. Close this window to finish.</p>
  `}
];

const state = {
  idx: 0,
  completed: {},
  score: 0,
  passed: false
};

function $(sel){ return document.querySelector(sel); }
function renderTOC(){
  const toc = $(".toc-list");
  toc.innerHTML = "";
  slides.forEach((s, i)=>{
    const b = document.createElement("button");
    b.textContent = s.title + (state.completed[s.id] ? " ✓" : "");
    b.className = (i===state.idx) ? "active" : "";
    b.onclick = ()=>goTo(i);
    toc.appendChild(b);
  });
}

function renderSlide(){
  const s = slides[state.idx];
  const view = $(".slide");
  let inner = "";
  if(s.type==="content"){
    inner = s.html;
  }else if(s.type==="quiz"){
    inner = `
      <h2>${s.title}</h2>
      <p>${s.question}</p>
      ${s.choices.map((c, i)=>`
        <div><label><input type="radio" name="q" value="${i}"> ${c}</label></div>
      `).join("")}
      <div class="controls">
        <button id="submit">Submit Answer</button>
        <span class="badge">Score: <span class="score">${state.score}</span></span>
      </div>
    `;
  }
  view.innerHTML = inner;
  $(".pos").textContent = `${state.idx+1}/${slides.length}`;
  $(".title").textContent = s.title;
  renderTOC();

  if(s.type==="quiz"){
    $("#submit").onclick = ()=>{
      const chosen = [...document.querySelectorAll('input[name="q"]')].find(r=>r.checked);
      if(!chosen) { alert("Choose an answer"); return; }
      const correct = Number(chosen.value) === s.correctIndex;
      if(correct){ state.score = 100; state.passed = true; alert("Correct!"); }
      else { state.score = 0; state.passed = false; alert("Oops!"); }
      state.completed[s.id] = true;
      persist();
      updateScormCompletion();
      renderSlide();
    };
  }else{
    state.completed[s.id] = true;
    persist();
    updateScormCompletion();
  }
}

function next(){ if(state.idx < slides.length-1){ state.idx++; persist(); renderSlide(); } }
function prev(){ if(state.idx > 0){ state.idx--; persist(); renderSlide(); } }
function goTo(i){ state.idx = i; persist(); renderSlide(); }

function persist(){
  // Save to SCORM
  if(window.SCORM && SCORM.isReady()){
    const s = JSON.stringify({idx:state.idx,completed:state.completed,score:state.score,passed:state.passed});
    SCORM.LMSSetValue("cmi.core.lesson_location", String(state.idx));
    SCORM.LMSSetValue("cmi.suspend_data", s);
    SCORM.LMSSetValue("cmi.core.score.raw", String(state.score));
    SCORM.LMSCommit("");
  }
  // Save to localStorage as fallback for testing outside LMS
  try{ localStorage.setItem("demo_state", JSON.stringify(state)); }catch(e){}
}

function restore(){
  // Try SCORM first
  if(window.SCORM && SCORM.isReady()){
    const loc = SCORM.LMSGetValue("cmi.core.lesson_location");
    const s = SCORM.LMSGetValue("cmi.suspend_data");
    if(s){ Object.assign(state, JSON.parse(s)); }
    else if(loc){ state.idx = parseInt(loc,10)||0; }
  }else{
    try{
      const raw = localStorage.getItem("demo_state");
      if(raw) Object.assign(state, JSON.parse(raw));
    }catch(e){}
  }
}

function updateScormCompletion(){
  const allDone = slides.every(sl=> sl.type==="content" ? state.completed[sl.id] : true) && state.completed["quiz1"];
  if(window.SCORM && SCORM.isReady()){
    const status = allDone ? (state.passed ? "passed" : "completed") : "incomplete";
    SCORM.LMSSetValue("cmi.core.lesson_status", status);
    SCORM.LMSSetValue("cmi.core.score.raw", String(state.score));
    SCORM.LMSCommit("");
    $(".status").textContent = status;
  }
  $(".score").textContent = state.score;
}

function init(){
  if(window.SCORM){
    SCORM.LMSInitialize("");
  }
  restore();
  renderSlide();
  updateScormCompletion();
}

window.addEventListener("load", init);
window.addEventListener("beforeunload", function(){
  if(window.SCORM){
    SCORM.LMSCommit("");
    SCORM.LMSFinish("");
  }
});
window.next = next;
window.prev = prev;
